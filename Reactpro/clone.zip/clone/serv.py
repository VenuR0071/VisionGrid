import cv2
from flask import Flask, Response, request, jsonify
from flask_cors import CORS
import sqlite3
import os
import threading

app = Flask(__name__)
CORS(app)

# Create the database file if it doesn't exist
if not os.path.exists('cameras.db'):
    conn = sqlite3.connect('cameras.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS cameras (camera_id INTEGER PRIMARY KEY, rtsp_url TEXT)''')
    conn.commit()
    conn.close()

def generate_stream(rtsp_url):
    cap = cv2.VideoCapture(rtsp_url)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                continue  # Skip frames that could not be read
            _, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    except Exception as e:
        print(f"Error generating stream: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()

def fetch_single_frame(rtsp_url):
    cap = cv2.VideoCapture(rtsp_url)
    ret, frame = cap.read()
    if not ret:
        return None
    _, buffer = cv2.imencode('.jpg', frame)
    frame = buffer.tobytes()
    cap.release()
    return frame

def video_feed(camera_id):
    conn = sqlite3.connect('cameras.db')
    c = conn.cursor()
    c.execute("SELECT rtsp_url FROM cameras WHERE camera_id = ?", (camera_id,))
    result = c.fetchone()
    conn.close()
    if result is None:
        return "Camera not found", 404
    rtsp_url = result[0]
    return Response(generate_stream(rtsp_url), mimetype='multipart/x-mixed-replace; boundary=frame')


@app.route('/add_camera', methods=['POST'])
def add_camera():
    data = request.json
    if 'camera_id' not in data or 'rtsp_url' not in data:
        return jsonify({"message": "Both camera_id and rtsp_url are required"}), 400
    camera_id = data['camera_id']
    rtsp_url = data['rtsp_url']
    conn = sqlite3.connect('cameras.db')
    c = conn.cursor()
    c.execute("SELECT * FROM cameras WHERE camera_id = ?", (camera_id,))
    result = c.fetchone()
    if result is not None:
        conn.close()
        return jsonify({"message": "Camera already exists"}), 400
    c.execute("INSERT INTO cameras (camera_id, rtsp_url) VALUES (?, ?)", (camera_id, rtsp_url))
    conn.commit()
    conn.close()
    return jsonify({"message": "Camera added successfully"})

@app.route('/delete_camera/<int:camera_id>', methods=['DELETE'])
def delete_camera(camera_id):
    conn = sqlite3.connect('cameras.db')
    c = conn.cursor()
    c.execute("SELECT * FROM cameras WHERE camera_id = ?", (camera_id,))
    result = c.fetchone()
    if result is None:
        conn.close()
        return jsonify({"message": "Camera not found"}), 404
    c.execute("DELETE FROM cameras WHERE camera_id = ?", (camera_id,))
    conn.commit()
    conn.close()
    return jsonify({"message": "Camera deleted successfully"})

@app.route('/single_frame/<int:camera_id>', methods=['GET'])
def single_frame(camera_id):
    conn = sqlite3.connect('cameras.db')
    c = conn.cursor()
    c.execute("SELECT rtsp_url FROM cameras WHERE camera_id = ?", (camera_id,))
    result = c.fetchone()
    conn.close()
    if result is None:
        return "Camera not found", 404
    rtsp_url = result[0]
    frame = fetch_single_frame(rtsp_url)
    if frame is None:
        return "Unable to fetch frame", 500
    return Response(frame, mimetype='image/jpeg')

@app.route('/camera/<int:camera_id>', methods=['GET'])
def camera_route(camera_id):
    return video_feed(camera_id)

if __name__ == '__main__':
    # Run the Flask app on a separate thread
    app_thread = threading.Thread(target=app.run, kwargs={'host': '0.0.0.0', 'port': 5000})
    app_thread.start()