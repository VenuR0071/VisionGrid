import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Container, Grid, Paper, Typography, TextField, Button, Box, CircularProgress } from '@mui/material';
import axios from 'axios';

const CameraStream = ({ cameraId, onDelete, onClick, frameUrl, showDelete }) => {
  return (
    <Paper elevation={3} sx={{ p: 2, borderRadius: 8 }}>
      <Box display="flex" flexDirection="column" alignItems="center">
        <Typography variant="subtitle1" align="center" gutterBottom>
          Camera {cameraId}
        </Typography>
        <Box position="relative" onClick={() => onClick(cameraId)} sx={{ cursor: 'pointer', borderRadius: 4, overflow: 'hidden' }}>
          <img
            src={frameUrl}
            alt={`Camera ${cameraId}`}
            width="100%"
            style={{ borderRadius: 4 }}
          />
        </Box>
        {showDelete && (
          <Button variant="outlined" color="error" onClick={() => onDelete(cameraId)} fullWidth sx={{ mt: 1 }}>
            Delete Camera
          </Button>
        )}
      </Box>
    </Paper>
  );
};

const App = () => {
  const [cameras, setCameras] = useState([]);
  const [cameraId, setCameraId] = useState('');
  const [rtspUrl, setRtspUrl] = useState('');
  const [addError, setAddError] = useState('');
  const [selectedCamera, setSelectedCamera] = useState(null);
  const [loading, setLoading] = useState(false);
  const [canvasSize, setCanvasSize] = useState({ width: 1920, height: 1080 });
  const canvasRef = useRef(null);

  const handleAddCamera = useCallback(async () => {
    if (!cameraId || !rtspUrl) {
      setAddError('Both Camera ID and RTSP URL are required');
      return;
    }

    setLoading(true);
    try {
      await axios.post('http://localhost:5000/add_camera', {
        camera_id: parseInt(cameraId),
        rtsp_url: rtspUrl,
      });

      const response = await axios.get(`http://localhost:5000/single_frame/${cameraId}`, { responseType: 'blob' });
      const frameUrl = URL.createObjectURL(new Blob([response.data], { type: 'image/jpeg' }));

      setCameras([...cameras, { cameraId: parseInt(cameraId), rtspUrl, frameUrl }]);
      setCameraId('');
      setRtspUrl('');
      setAddError('');
    } catch (error) {
      console.error('Error adding camera:', error);
      setAddError('Error adding camera');
    } finally {
      setLoading(false);
    }
  }, [cameraId, rtspUrl, cameras]);

  const handleDeleteCamera = useCallback(async (deletedCameraId) => {
    setLoading(true);
    try {
      await axios.delete(`http://localhost:5000/delete_camera/${deletedCameraId}`);
      setCameras(cameras.filter((camera) => camera.cameraId !== deletedCameraId));
    } catch (error) {
      console.error('Error deleting camera:', error);
    } finally {
      setLoading(false);
    }
  }, [cameras]);

  const handleCameraClick = useCallback((cameraId) => {
    setSelectedCamera(cameraId);
  }, []);

  useEffect(() => {
    if (!selectedCamera || !cameras.some((camera) => camera.cameraId === selectedCamera)) return;

    const videoSrc = `http://localhost:5000/camera/${selectedCamera}`;
    const img = new Image();
    img.src = videoSrc;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');

    let animationFrameId;

    const drawFrame = () => {
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      animationFrameId = requestAnimationFrame(drawFrame);
    };

    img.onload = () => {
      setCanvasSize({ width: img.width, height: img.height });
      canvas.width = img.width;
      canvas.height = img.height;
      drawFrame();
    };

    img.onerror = (e) => {
      console.error('Error loading image:', e);
      // Handle error, e.g., show an error message or retry loading
    };

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [selectedCamera, cameras]);

  // Calculate the scale factor and set the transform property accordingly
  const scaleFactor = Math.min(864 / canvasSize.width, 486 / canvasSize.height);

  return (
    <Container maxWidth={false} sx={{ mt: 2, transform: 'scale(0.9)', flexDirection: 'column', height: '100vh' }}>
      <Typography variant="h5" gutterBottom>
        IP Camera Dashboard
      </Typography>
      <Paper elevation={3} sx={{ p: 2, mb: 2, borderRadius: 8 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} sm={4}>
            <TextField
              label="Camera ID"
              value={cameraId}
              onChange={(e) => setCameraId(e.target.value)}
              fullWidth
              variant="outlined"
              size="small"
              InputProps={{ sx: { borderRadius: 4 } }}
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="RTSP URL"
              value={rtspUrl}
              onChange={(e) => setRtspUrl(e.target.value)}
              fullWidth
              variant="outlined"
              size="small"
              InputProps={{ sx: { borderRadius: 4 } }}
            />
          </Grid>
          <Grid item xs={12} sm={2}>
            <Button variant="contained" color="primary" onClick={handleAddCamera} fullWidth>
              {loading ? <CircularProgress size={24} /> : 'Add Camera'}
            </Button>
          </Grid>
        </Grid>
        {addError && (
          <Typography variant="body2" color="error" sx={{ mt: 1 }}>
            {addError}
          </Typography>
        )}
      </Paper>
      <Box sx={{ display: 'flex', flexGrow: 1, gap: 2 }}>
        <Grid container spacing={3} sx={{ flexGrow: 1 }}>
          <Grid item xs={4}>
            <Box sx={{ backgroundColor: '#f0f0f0', height: '105%', borderRadius: 2, overflow: 'auto', padding: 1 }}>
              <Grid container spacing={2} sx={{ height: '80%' }}>
                {cameras.map((camera) => (
                  <Grid item xs={6} key={camera.cameraId} sx={{ height: '50%' }}>
                    <CameraStream
                      cameraId={camera.cameraId}
                      onDelete={handleDeleteCamera}
                      onClick={handleCameraClick}
                      frameUrl={camera.frameUrl}
                      showDelete={true}
                    />
                  </Grid>
                ))}
              </Grid>
            </Box>
          </Grid>
          <Grid item xs={8}>
            <Box sx={{ backgroundColor: '#e0e0e0', height: '486px', width: '864px', display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: 2, overflow: 'hidden', padding: 1 }}>
              <canvas
                ref={canvasRef}
                style={{ border: 'none', borderRadius: 1, transform: `scale(${scaleFactor})` }}
                width={canvasSize.width}
                height={canvasSize.height}
              />
            </Box>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
};

export default App;
